package com.zaraplastic.labourproduction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private ProgressBar progress;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        progress = findViewById(R.id.progress);
        status = findViewById(R.id.status);

        signInWithoutLogin();
    }

    private void signInWithoutLogin() {
        progress.setVisibility(View.VISIBLE);
        status.setText("Opening Zara Plastic Labour App...");

        if (auth.getCurrentUser() != null) {
            ensureUserProfile(auth.getCurrentUser().getUid());
            return;
        }

        auth.signInAnonymously()
            .addOnCompleteListener(task -> {
                if (task.isSuccessful() && auth.getCurrentUser() != null) {
                    ensureUserProfile(auth.getCurrentUser().getUid());
                } else {
                    progress.setVisibility(View.GONE);
                    status.setText("App open nahi ho pa raha. Firebase Anonymous Login check karein.");
                }
            });
    }

    private void ensureUserProfile(String uid) {
        Map<String, Object> user = new HashMap<>();
        user.put("role", "owner");
        user.put("loginType", "anonymous");

        db.collection("users").document(uid).set(user)
            .addOnSuccessListener(v -> openMain())
            .addOnFailureListener(e -> {
                progress.setVisibility(View.GONE);
                status.setText("Firebase connection error: " + e.getMessage());
            });
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
