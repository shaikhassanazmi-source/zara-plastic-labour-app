package com.zaraplastic.labourproduction;

import android.content.*;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {
    FirebaseFirestore db; FirebaseAuth auth;
    TextView role, dashboardSummary;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance();
        role=findViewById(R.id.role); dashboardSummary=findViewById(R.id.dashboardSummary);

        findViewById(R.id.addLabourPartyBtn).setOnClickListener(v->addLabourPartyDialog(null));
        findViewById(R.id.searchLabourPartyBtn).setOnClickListener(v->labourPartyHisab());
        findViewById(R.id.labourBtn).setOnClickListener(v->labourJobDialog());
        findViewById(R.id.labourPartyHisabBtn).setOnClickListener(v->labourPartyHisab());
        findViewById(R.id.reportBtn).setOnClickListener(v->report());
        findViewById(R.id.monthlyStatementBtn).setOnClickListener(v->monthlyStatement());
        findViewById(R.id.backupBtn).setOnClickListener(v->backupCsv());
        findViewById(R.id.logoutBtn).setOnClickListener(v->{auth.signOut(); startActivity(new Intent(this,LoginActivity.class)); finish();});
        loadRole(); loadSummary();
    }

    void loadRole(){
        if(auth.getCurrentUser()==null)return;
        db.collection("users").document(auth.getCurrentUser().getUid()).get()
          .addOnSuccessListener(s->{String r=s.exists()?s.getString("role"):"owner"; role.setText("Role: "+(r==null?"owner":r)+" • Anonymous login");});
    }

    EditText field(String hint, boolean number){
        EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true);
        if(number)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    void addLabourPartyDialog(Spinner spinner){
        EditText e=field("Labour party name",false);
        new AlertDialog.Builder(this).setTitle("Add Labour Party").setView(e)
          .setPositiveButton("Save",(d,w)->{
              String n=e.getText().toString().trim();
              if(n.isEmpty()){toast("Party name bharein");return;}
              db.collection("labourParties").whereEqualTo("name",n).limit(1).get().addOnSuccessListener(q->{
                  if(!q.isEmpty()){toast("Party already added"); if(spinner!=null)loadSpinnerValues("labourParties","name",spinner,"No labour party added"); return;}
                  Map<String,Object> m=new HashMap<>(); m.put("name",n); m.put("createdAt",FieldValue.serverTimestamp()); m.put("createdBy",auth.getUid());
                  db.collection("labourParties").add(m).addOnSuccessListener(x->{toast("Labour party added"); if(spinner!=null)loadSpinnerValues("labourParties","name",spinner,"No labour party added"); loadSummary();});
              });
          }).setNegativeButton("Cancel",null).show();
    }

    void labourJobDialog(){
        LinearLayout l=box();
        LinearLayout partyRow=new LinearLayout(this); partyRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner partySpinner=new Spinner(this); Button addParty=smallButton("+ Add Party");
        partyRow.addView(partySpinner,new LinearLayout.LayoutParams(0,-2,1)); partyRow.addView(addParty);
        l.addView(label("Labour Party")); l.addView(partyRow);

        LinearLayout materialRow=new LinearLayout(this); materialRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner materialSpinner=new Spinner(this); Button addMaterial=smallButton("+ Add Material");
        materialRow.addView(materialSpinner,new LinearLayout.LayoutParams(0,-2,1)); materialRow.addView(addMaterial);
        l.addView(label("Material / Powder")); l.addView(materialRow);

        EditText given=field("Material Given KG (e.g. 100)",true);
        EditText returned=field("Material Returned KG (optional)",true);
        EditText product=field("Item / Product (e.g. Royal Cup)",false);
        EditText pieces=field("Pieces Made (e.g. 400)",true);
        EditText output=field("Finished Weight KG (e.g. 60)",true);
        l.addView(given); l.addView(returned); l.addView(product); l.addView(pieces); l.addView(output);

        loadSpinnerValues("labourParties","name",partySpinner,"No labour party added");
        loadSpinnerValues("materials","name",materialSpinner,"No material added");
        addParty.setOnClickListener(v->addLabourPartyDialog(partySpinner));
        addMaterial.setOnClickListener(v->addMaterialDialog(materialSpinner));

        new AlertDialog.Builder(this).setTitle("Labour Job")
          .setMessage("Party ko kitna material diya aur kitna item bana, Pieces + KG me bharein")
          .setView(l).setPositiveButton("Save",(d,w)->{
            String party=selectedSpinner(partySpinner), material=selectedSpinner(materialSpinner);
            String productName=product.getText().toString().trim();
            if(party.isEmpty() || party.startsWith("No ")){toast("Pehle labour party add karein");return;}
            if(material.isEmpty() || material.startsWith("No ")){toast("Pehle material add karein");return;}
            if(productName.isEmpty()){toast("Product name bharein");return;}
            try{
                double g=Double.parseDouble(given.getText().toString().trim());
                double r=returned.getText().toString().trim().isEmpty()?0:Double.parseDouble(returned.getText().toString().trim());
                double p=pieces.getText().toString().trim().isEmpty()?0:Double.parseDouble(pieces.getText().toString().trim());
                double o=Double.parseDouble(output.getText().toString().trim());
                if(g<=0 || r<0 || p<0 || o<0){toast("Values sahi bharein");return;}
                if(r>g){toast("Returned KG given KG se zyada nahi ho sakta");return;}
                Map<String,Object> m=new HashMap<>();
                m.put("party",party); m.put("material",material); m.put("givenKg",g); m.put("returnedPowderKg",r);
                m.put("product",productName); m.put("pieces",p); m.put("outputKg",o);
                m.put("createdAt",FieldValue.serverTimestamp()); m.put("createdBy",auth.getUid());
                db.collection("labourJobs").add(m).addOnSuccessListener(x->{toast("Saved: "+party+" → "+productName+" → "+fmt(p)+" pcs / "+fmt(o)+" KG");loadSummary();});
            }catch(Exception e){toast("KG aur Pieces sahi bharein");}
          }).setNegativeButton("Cancel",null).show();
    }

    void addMaterialDialog(Spinner spinner){
        EditText e=field("Material / Powder name",false);
        new AlertDialog.Builder(this).setTitle("Add Material").setView(e)
          .setPositiveButton("Save",(d,w)->{
              String n=e.getText().toString().trim(); if(n.isEmpty()){toast("Material name bharein");return;}
              db.collection("materials").whereEqualTo("name",n).limit(1).get().addOnSuccessListener(q->{
                  if(!q.isEmpty()){toast("Material already added");loadSpinnerValues("materials","name",spinner,"No material added");return;}
                  Map<String,Object> m=new HashMap<>();m.put("name",n);m.put("createdAt",FieldValue.serverTimestamp());m.put("createdBy",auth.getUid());
                  db.collection("materials").add(m).addOnSuccessListener(x->{toast("Material added");loadSpinnerValues("materials","name",spinner,"No material added");});
              });
          }).setNegativeButton("Cancel",null).show();
    }

    void labourPartyHisab(){
        db.collection("labourJobs").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener(q->{
            if(q.isEmpty()){new AlertDialog.Builder(this).setTitle("Labour Party Hisab").setMessage("No labour jobs yet").setPositiveButton("OK",null).show();return;}
            LinkedHashMap<String,Double> givenTotals=new LinkedHashMap<>(), returnedTotals=new LinkedHashMap<>(), pieceTotals=new LinkedHashMap<>(), kgTotals=new LinkedHashMap<>();
            LinkedHashMap<String,LinkedHashMap<String,String>> itemTotals=new LinkedHashMap<>();
            for(DocumentSnapshot s:q){
                String party=s.getString("party"); if(party==null||party.trim().isEmpty())party="Unknown";
                String product=s.getString("product"); if(product==null||product.trim().isEmpty())product="Unknown Item";
                givenTotals.put(party,givenTotals.getOrDefault(party,0.0)+val(s.getDouble("givenKg")));
                returnedTotals.put(party,returnedTotals.getOrDefault(party,0.0)+val(s.getDouble("returnedPowderKg")));
                pieceTotals.put(party,pieceTotals.getOrDefault(party,0.0)+val(s.getDouble("pieces")));
                kgTotals.put(party,kgTotals.getOrDefault(party,0.0)+val(s.getDouble("outputKg")));
                if(!itemTotals.containsKey(party))itemTotals.put(party,new LinkedHashMap<>());
                String old=itemTotals.get(party).get(product); double oldP=0,oldK=0;
                if(old!=null){String[] z=old.split("\\|"); oldP=Double.parseDouble(z[0]); oldK=Double.parseDouble(z[1]);}
                itemTotals.get(party).put(product,(oldP+val(s.getDouble("pieces")))+"|"+(oldK+val(s.getDouble("outputKg"))));
            }
            LinearLayout l=box(); EditText search=field("Search labour party",false); l.addView(search); TextView result=new TextView(this);result.setTextSize(16);result.setPadding(0,16,0,8);l.addView(result);
            Runnable render=()->{String term=search.getText().toString().trim().toLowerCase(Locale.US);StringBuilder out=new StringBuilder();
                for(String party:givenTotals.keySet()){
                    if(!term.isEmpty()&&!party.toLowerCase(Locale.US).contains(term))continue;
                    out.append("PARTY: ").append(party).append("\n");
                    out.append("Material Given: ").append(fmt(givenTotals.get(party))).append(" KG\n");
                    out.append("Material Returned: ").append(fmt(returnedTotals.get(party))).append(" KG\n");
                    out.append("Total Production: ").append(fmt(pieceTotals.get(party))).append(" pcs / ").append(fmt(kgTotals.get(party))).append(" KG\n");
                    out.append("Item-wise:\n");
                    for(Map.Entry<String,String> e:itemTotals.get(party).entrySet()){String[] z=e.getValue().split("\\|");out.append("  ").append(e.getKey()).append(" → ").append(fmt(Double.parseDouble(z[0]))).append(" pcs / ").append(fmt(Double.parseDouble(z[1]))).append(" KG\n");}
                    out.append("\n");
                }
                if(out.length()==0)out.append("Labour party nahi mili");result.setText(out.toString());};
            render.run();search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}});
            new AlertDialog.Builder(this).setTitle("Labour Party Hisab").setView(l).setPositiveButton("Close",null).show();
        }).addOnFailureListener(e->toast("Labour hisab load nahi hua"));
    }

    void report(){
        db.collection("labourJobs").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener(q->{StringBuilder x=new StringBuilder();
            for(DocumentSnapshot s:q)x.append("Party: ").append(s.getString("party")).append("\nMaterial: ").append(s.getString("material")).append(" | Given ").append(fmt(s.getDouble("givenKg"))).append(" KG\n").append(s.getString("product")).append(" → ").append(fmt(s.getDouble("pieces"))).append(" pcs / ").append(fmt(s.getDouble("outputKg"))).append(" KG\n\n");
            new AlertDialog.Builder(this).setTitle("All Labour Jobs").setMessage(x.length()==0?"No entries":x.toString()).setPositiveButton("OK",null).show();});
    }

    void monthlyStatement(){
        LinearLayout l=box();
        Spinner partySpinner=new Spinner(this);
        ArrayList<String> parties=new ArrayList<>(); parties.add("All Parties");
        db.collection("labourParties").orderBy("name").get().addOnSuccessListener(pq->{for(DocumentSnapshot s:pq){String n=s.getString("name");if(n!=null&&!n.trim().isEmpty())parties.add(n);}ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,parties);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);partySpinner.setAdapter(a);});
        l.addView(label("Party")); l.addView(partySpinner);
        Calendar now=Calendar.getInstance();
        EditText month=field("Month (MM), e.g. 08",true); month.setText(String.format(Locale.US,"%02d",now.get(Calendar.MONTH)+1));
        EditText year=field("Year, e.g. 2026",true); year.setText(String.valueOf(now.get(Calendar.YEAR)));
        EditText percent=field("Minus percentage, e.g. 2",true); percent.setText("0");
        l.addView(month); l.addView(year); l.addView(percent);
        new AlertDialog.Builder(this).setTitle("Monthly Statement").setMessage("Party, month aur minus % bharein").setView(l)
          .setPositiveButton("Statement",(d,w)->{
            String party=selectedSpinner(partySpinner);
            try{
                int mo=Integer.parseInt(month.getText().toString().trim()); int yr=Integer.parseInt(year.getText().toString().trim());
                double pct=percent.getText().toString().trim().isEmpty()?0:Double.parseDouble(percent.getText().toString().trim());
                if(mo<1||mo>12||yr<2000||pct<0||pct>100){toast("Month, year aur percentage sahi bharein");return;}
                showMonthlyStatement(party,mo,yr,pct);
            }catch(Exception e){toast("Month, year aur percentage sahi bharein");}
          }).setNegativeButton("Cancel",null).show();
    }

    void showMonthlyStatement(String party,int month,int year,double pct){
        db.collection("labourJobs").orderBy("createdAt",Query.Direction.ASCENDING).get().addOnSuccessListener(q->{
            double given=0,returned=0,pieces=0,kg=0; int count=0;
            LinkedHashMap<String,Double> itemPieces=new LinkedHashMap<>(), itemKg=new LinkedHashMap<>();
            Calendar start=Calendar.getInstance(); start.clear(); start.set(year,month-1,1,0,0,0);
            Calendar end=(Calendar)start.clone(); end.add(Calendar.MONTH,1);
            for(DocumentSnapshot s:q){
                String p=s.getString("party"); if(!"All Parties".equals(party) && !party.equals(p))continue;
                Object o=s.get("createdAt"); if(!(o instanceof Timestamp))continue;
                Date dt=((Timestamp)o).toDate(); if(dt.before(start.getTime())||!dt.before(end.getTime()))continue;
                count++; given+=val(s.getDouble("givenKg")); returned+=val(s.getDouble("returnedPowderKg")); pieces+=val(s.getDouble("pieces")); kg+=val(s.getDouble("outputKg"));
                String product=s.getString("product"); if(product==null||product.trim().isEmpty())product="Unknown Item";
                itemPieces.put(product,itemPieces.getOrDefault(product,0.0)+val(s.getDouble("pieces")));
                itemKg.put(product,itemKg.getOrDefault(product,0.0)+val(s.getDouble("outputKg")));
            }
            double pieceMinus=pieces*pct/100.0, kgMinus=kg*pct/100.0; double netPieces=pieces-pieceMinus, netKg=kg-kgMinus;
            StringBuilder out=new StringBuilder();
            out.append("MONTHLY STATEMENT\n").append(String.format(Locale.US,"%02d/%04d",month,year)).append("\n");
            out.append("Party: ").append(party).append("\n\n");
            out.append("Entries: ").append(count).append("\n");
            out.append("Material Given: ").append(fmt(given)).append(" KG\n");
            out.append("Material Returned: ").append(fmt(returned)).append(" KG\n");
            out.append("Gross Production: ").append(fmt(pieces)).append(" pcs / ").append(fmt(kg)).append(" KG\n");
            out.append("Minus: ").append(fmt(pct)).append(" %\n");
            out.append("Minus Pieces: ").append(fmt(pieceMinus)).append("\n");
            out.append("Minus KG: ").append(fmt(kgMinus)).append(" KG\n");
            out.append("NET: ").append(fmt(netPieces)).append(" pcs / ").append(fmt(netKg)).append(" KG\n\n");
            out.append("ITEM-WISE\n");
            for(String item:itemPieces.keySet())out.append(item).append(" → ").append(fmt(itemPieces.get(item))).append(" pcs / ").append(fmt(itemKg.get(item))).append(" KG\n");
            if(count==0)out.append("\nIs month me koi entry nahi mili.");
            new AlertDialog.Builder(this).setTitle("Monthly Statement").setMessage(out.toString()).setPositiveButton("OK",null).show();
        }).addOnFailureListener(e->toast("Monthly statement load nahi hua"));
    }

    void backupCsv(){
        db.collection("labourJobs").get().addOnSuccessListener(q->{StringBuilder c=new StringBuilder("Party,Material,GivenKG,ReturnedKG,Product,Pieces,OutputKG\n");
            for(DocumentSnapshot s:q)c.append(csv(s.getString("party"))).append(',').append(csv(s.getString("material"))).append(',').append(fmt(s.getDouble("givenKg"))).append(',').append(fmt(s.getDouble("returnedPowderKg"))).append(',').append(csv(s.getString("product"))).append(',').append(fmt(s.getDouble("pieces"))).append(',').append(fmt(s.getDouble("outputKg"))).append('\n');
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/csv");i.putExtra(Intent.EXTRA_TEXT,c.toString());startActivity(Intent.createChooser(i,"Labour Backup share karein"));});
    }

    void loadSummary(){
        db.collection("labourParties").get().addOnSuccessListener(pq->db.collection("labourJobs").get().addOnSuccessListener(q->{
            double given=0,returned=0,pieces=0,output=0;for(DocumentSnapshot s:q){given+=val(s.getDouble("givenKg"));returned+=val(s.getDouble("returnedPowderKg"));pieces+=val(s.getDouble("pieces"));output+=val(s.getDouble("outputKg"));}
            dashboardSummary.setText("Labour Parties: "+pq.size()+"\nMaterial Given: "+fmt(given)+" KG\nMaterial Returned: "+fmt(returned)+" KG\nItems Made: "+fmt(pieces)+" pcs\nFinished Weight: "+fmt(output)+" KG");
        }));
    }

    void loadSpinnerValues(String collection,String fieldName,Spinner spinner,String emptyLabel){
        db.collection(collection).orderBy(fieldName).get().addOnSuccessListener(q->{ArrayList<String> v=new ArrayList<>();for(DocumentSnapshot s:q){String x=s.getString(fieldName);if(x!=null&&!x.trim().isEmpty())v.add(x);}if(v.isEmpty())v.add(emptyLabel);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,v);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(a);}).addOnFailureListener(e->{ArrayList<String>v=new ArrayList<>();v.add(emptyLabel);spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,v));});
    }
    String selectedSpinner(Spinner s){Object o=s.getSelectedItem();return o==null?"":o.toString().trim();}
    TextView label(String t){TextView x=new TextView(this);x.setText(t);x.setTextSize(14);x.setPadding(0,8,0,0);return x;}
    Button smallButton(String t){Button b=new Button(this);b.setText(t);b.setTextSize(11);return b;}
    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(30,10,30,10);return l;}
    double val(Double d){return d==null?0:d;} String fmt(Double d){return String.format(Locale.US,"%.3f",val(d));}
    String csv(String s){return "\""+(s==null?"":s.replace("\"","\"\""))+"\"";} void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
