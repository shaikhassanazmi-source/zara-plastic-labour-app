# Labour Job Update

Labour Job now supports:
- Add Labour Party (separate list; duplicate names blocked)
- Select Labour Party from a searchable-style spinner list
- Select Material/Powder from the Materials list
- Add Material directly from Labour Job
- Enter Powder Given KG
- Enter Unused Powder Returned KG
- Enter Product Made
- Enter Finished Item Output KG
- Prevent Returned KG from exceeding Given KG
- Labour job records are saved to `labourJobs`
- Labour party master records are saved to `labourParties`

Firestore rule for `labourParties` is included in `firestore.rules`.
