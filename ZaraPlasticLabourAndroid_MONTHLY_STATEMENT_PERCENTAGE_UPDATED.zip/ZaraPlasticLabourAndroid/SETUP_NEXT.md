# Next setup

1. Firebase Console → Authentication → Sign-in method → Anonymous → Enabled.
2. Open the Android project in Android Studio.
3. Sync Gradle.
4. Build/run on a physical Android phone.
5. The app now opens without Phone OTP.
6. On first launch, Firebase creates an anonymous user and the app creates `users/<UID>` with `role: owner`.
7. Publish the included Firestore rules after reviewing them.

8. Purchase screen: select Supplier Party, use + Add Party, select Material/Powder, use + Add Material, then enter Purchase KG.
9. Purchase History shows Party → Material → KG for every purchase.
