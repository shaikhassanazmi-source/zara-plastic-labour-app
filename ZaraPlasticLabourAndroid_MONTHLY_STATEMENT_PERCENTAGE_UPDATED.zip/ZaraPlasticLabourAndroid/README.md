# Zara Plastic Labour Production - Android Firebase Project

Package: `com.zaraplastic.labourproduction`

Firebase project: `zara-plastic`

## Login
- Phone/OTP login removed.
- Firebase Anonymous Authentication is used.
- App automatically signs in without asking for a mobile number or OTP.
- The first anonymous account is automatically given `role: owner`.

## Included
- Firebase Anonymous authentication
- Cloud Firestore connection
- Party/Labour/Production data model
- 2% cutting calculation
- Monthly reporting foundation
- CSV export foundation
- Owner/Manager role read from Firestore

## Important
Anonymous authentication must be enabled in Firebase Authentication.

The app automatically creates `users/<Firebase UID>` with:
- `role = owner`
- `loginType = anonymous`

For a private production deployment with multiple users, add proper organization/user access rules before sharing the app publicly.

## Updated Labour / Powder Tracking
- Add party once; duplicate party names are blocked and parties can be searched.
- Material purchase records supplier party, material/powder and purchased KG.
- Labour job records labour party, material, powder given KG, unused powder returned KG, product name and finished output KG.
- Powder balance = purchased KG - given KG + returned powder KG.
- Current stock and labour hisab screens are included.
