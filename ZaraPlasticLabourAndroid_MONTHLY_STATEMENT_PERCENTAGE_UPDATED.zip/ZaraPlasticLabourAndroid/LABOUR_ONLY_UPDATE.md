Labour-only update

Purchase screen/options removed from dashboard.
Labour Job now records:
- Labour party
- Material/powder
- Material given KG
- Material returned KG (optional)
- Product/item name
- Pieces made
- Finished weight KG

Example: A gets 100 KG, B gets 200 KG; Royal Cup 400 pieces = 60 KG.
Labour Party Hisab shows party totals and item-wise pieces + KG.
