# Next setup
1. Open in Android Studio.
2. Sync Gradle.
3. Build/run on a physical Android phone.
4. Phone OTP is already wired to Firebase.
5. After the first user logs in, create `users/<UID>` in Firestore with `role: owner` (or add a bootstrap flow before production).
6. Publish the Firestore rules from `firestore.rules` after reviewing them.
7. For Phone Auth production, add the app SHA-1/SHA-256 fingerprints in Firebase project settings and follow Firebase's verification setup.
