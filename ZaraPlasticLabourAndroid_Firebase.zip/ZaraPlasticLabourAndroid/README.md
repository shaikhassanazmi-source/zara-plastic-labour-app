# Zara Plastic Labour Production - Android Firebase Project

Package: `com.zaraplastic.labourproduction`

Firebase project: `zara-plastic`

## Included
- Firebase Phone OTP authentication
- Cloud Firestore connection
- Party/Labour/Production data model
- 2% cutting calculation
- Monthly reporting foundation
- CSV export foundation
- Owner/Manager role read from Firestore

## Important
The Firebase config file is already placed at `app/google-services.json`.

Before first real login, create the first owner's Firestore role document:
`users/<Firebase UID>` with field `role = owner`.

For production, configure Firestore Security Rules so users can only access their organization's data. Do not leave the database open.

## Current app state
This is a Firebase-connected Android source prototype. It is not a signed APK yet.
