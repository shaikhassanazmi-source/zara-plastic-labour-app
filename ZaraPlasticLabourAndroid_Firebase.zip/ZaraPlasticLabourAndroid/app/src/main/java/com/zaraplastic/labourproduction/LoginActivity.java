package com.zaraplastic.labourproduction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.*;
import java.util.concurrent.TimeUnit;

public class LoginActivity extends AppCompatActivity {
    FirebaseAuth auth; EditText mobile, otp; Button send, verify; TextView status; ProgressBar progress; String verificationId;
    PhoneAuthProvider.ForceResendingToken resendToken;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_login);auth=FirebaseAuth.getInstance();
      mobile=findViewById(R.id.mobile);otp=findViewById(R.id.otp);send=findViewById(R.id.sendOtp);verify=findViewById(R.id.verifyOtp);status=findViewById(R.id.status);progress=findViewById(R.id.progress);
      send.setOnClickListener(v->sendOtp()); verify.setOnClickListener(v->verifyOtp()); }
    void busy(boolean x){progress.setVisibility(x?View.VISIBLE:View.GONE);send.setEnabled(!x);verify.setEnabled(!x);}
    void sendOtp(){String n=mobile.getText().toString().replaceAll("\\D",""); if(n.length()!=10){status.setText("10 digit mobile number enter karein.");return;} String phone="+91"+n;busy(true);
      PhoneAuthOptions options=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
        @Override public void onVerificationCompleted(PhoneAuthCredential c){auth.signInWithCredential(c).addOnCompleteListener(t->{if(t.isSuccessful())openMain();});}
        @Override public void onVerificationFailed(FirebaseException e){busy(false);status.setText("OTP error: "+e.getMessage());}
        @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token){busy(false);verificationId=id;resendToken=token;otp.setVisibility(View.VISIBLE);verify.setVisibility(View.VISIBLE);send.setVisibility(View.GONE);status.setText("OTP bheja gaya hai.");}
      }).build(); PhoneAuthProvider.verifyPhoneNumber(options); }
    void verifyOtp(){String code=otp.getText().toString().trim();if(code.length()<6){status.setText("6 digit OTP enter karein.");return;}busy(true);PhoneAuthCredential c=PhoneAuthProvider.getCredential(verificationId,code);auth.signInWithCredential(c).addOnCompleteListener(t->{busy(false);if(t.isSuccessful())openMain();else status.setText("OTP verify nahi hua.");});}
    void openMain(){startActivity(new Intent(this,MainActivity.class));finish();}
}
