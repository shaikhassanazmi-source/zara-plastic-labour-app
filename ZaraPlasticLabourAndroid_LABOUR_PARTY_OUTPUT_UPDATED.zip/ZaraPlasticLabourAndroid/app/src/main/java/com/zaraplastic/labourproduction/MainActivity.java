package com.zaraplastic.labourproduction;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    FirebaseFirestore db; FirebaseAuth auth;
    TextView role, summary, dashboardSummary;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance();
        role=findViewById(R.id.role); summary=findViewById(R.id.summary); dashboardSummary=findViewById(R.id.dashboardSummary);

        findViewById(R.id.addPartyBtn).setOnClickListener(v->addPartyDialog());
        findViewById(R.id.searchPartyBtn).setOnClickListener(v->partyList());
        findViewById(R.id.purchaseBtn).setOnClickListener(v->purchaseDialog());
        findViewById(R.id.purchaseHistoryBtn).setOnClickListener(v->purchaseHistory());
        findViewById(R.id.labourBtn).setOnClickListener(v->labourJobDialog());
        findViewById(R.id.stockBtn).setOnClickListener(v->stockReport());
        findViewById(R.id.reportBtn).setOnClickListener(v->report());
        findViewById(R.id.labourPartyHisabBtn).setOnClickListener(v->labourPartyHisab());
        findViewById(R.id.backupBtn).setOnClickListener(v->backupCsv());
        findViewById(R.id.logoutBtn).setOnClickListener(v->{auth.signOut(); startActivity(new Intent(this,LoginActivity.class)); finish();});
        loadRole(); loadSummary();
    }

    void loadRole(){
        if(auth.getCurrentUser()==null)return;
        db.collection("users").document(auth.getCurrentUser().getUid()).get()
          .addOnSuccessListener(s->{String r=s.exists()?s.getString("role"):"owner"; role.setText("Role: "+r+" • Anonymous login");});
    }

    EditText field(String hint, boolean number){
        EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true);
        if(number)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    void addPartyDialog(){
        EditText e=field("Party name",false);
        new AlertDialog.Builder(this).setTitle("Add Party").setView(e)
          .setPositiveButton("Save",(d,w)->{
              String n=e.getText().toString().trim(); if(n.isEmpty())return;
              db.collection("parties").whereEqualTo("name",n).limit(1).get()
                .addOnSuccessListener(q->{ if(!q.isEmpty()){toast("Party already added"); return;}
                    Map<String,Object> m=new HashMap<>(); m.put("name",n); m.put("createdAt",FieldValue.serverTimestamp()); m.put("createdBy",auth.getUid());
                    db.collection("parties").add(m).addOnSuccessListener(x->toast("Party saved"));
                });
          }).setNegativeButton("Cancel",null).show();
    }

    void partyList(){
        db.collection("parties").orderBy("name").get().addOnSuccessListener(q->{
            LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,10,20,10);
            EditText search=field("Search party",false); l.addView(search);
            ListView list=new ListView(this); l.addView(list,new LinearLayout.LayoutParams(-1,500));
            ArrayList<String> all=new ArrayList<>(); for(DocumentSnapshot s:q) if(s.getString("name")!=null)all.add(s.getString("name"));
            ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<>(all)); list.setAdapter(a);
            search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ArrayList<String> x=new ArrayList<>(); for(String n:all)if(n.toLowerCase().contains(s.toString().toLowerCase()))x.add(n); a.clear();a.addAll(x);a.notifyDataSetChanged();} public void afterTextChanged(android.text.Editable e){}});
            new AlertDialog.Builder(this).setTitle("Party Search").setView(l).setPositiveButton("Close",null).show();
        });
    }

    void purchaseDialog(){
        LinearLayout l=box();
        LinearLayout partyRow=new LinearLayout(this); partyRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner partySpinner=new Spinner(this); Button addParty=smallButton("+ Add Party");
        partyRow.addView(partySpinner,new LinearLayout.LayoutParams(0,-2,1)); partyRow.addView(addParty);
        l.addView(label("Supplier Party")); l.addView(partyRow);

        LinearLayout materialRow=new LinearLayout(this); materialRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner materialSpinner=new Spinner(this); Button addMaterial=smallButton("+ Add Material");
        materialRow.addView(materialSpinner,new LinearLayout.LayoutParams(0,-2,1)); materialRow.addView(addMaterial);
        l.addView(label("Material / Powder")); l.addView(materialRow);
        EditText kg=field("Purchase KG",true); l.addView(kg);

        loadSpinnerValues("parties","name",partySpinner,"No party added");
        loadSpinnerValues("materials","name",materialSpinner,"No material added");
        addParty.setOnClickListener(v->addPartyDialog());
        addMaterial.setOnClickListener(v->addMaterialDialog(materialSpinner));

        new AlertDialog.Builder(this).setTitle("Purchase Material")
          .setMessage("Supplier party + material + quantity (KG) enter karein")
          .setView(l)
          .setPositiveButton("Save Purchase",(d,w)->{
              String party=selectedSpinner(partySpinner), material=selectedSpinner(materialSpinner);
              String kgText=kg.getText().toString().trim();
              if(party.isEmpty() || party.startsWith("No ")){toast("Pehle supplier party add karein");return;}
              if(material.isEmpty() || material.startsWith("No ")){toast("Pehle material add karein");return;}
              try{double k=Double.parseDouble(kgText); if(k<=0){toast("KG 0 se zyada hona chahiye");return;}
                  Map<String,Object> m=new HashMap<>();
                  m.put("party",party);m.put("material",material);m.put("kg",k);
                  m.put("createdAt",FieldValue.serverTimestamp());m.put("createdBy",auth.getUid());
                  db.collection("materialPurchases").add(m).addOnSuccessListener(x->{toast("Purchase saved: "+party+" → "+material+" → "+fmt(k)+" KG");loadSummary();});
              }catch(Exception e){toast("KG sahi bharein");}
          }).setNegativeButton("Cancel",null).setNeutralButton("Purchase History",(d,w)->purchaseHistory()).show();
    }

    void addMaterialDialog(Spinner spinner){
        EditText e=field("Material / Powder name",false);
        new AlertDialog.Builder(this).setTitle("Add Material").setView(e)
          .setPositiveButton("Save",(d,w)->{
              String n=e.getText().toString().trim(); if(n.isEmpty()){toast("Material name bharein");return;}
              db.collection("materials").whereEqualTo("name",n).limit(1).get().addOnSuccessListener(q->{
                  if(!q.isEmpty()){toast("Material already added");loadSpinnerValues("materials","name",spinner,"No material added");return;}
                  Map<String,Object> m=new HashMap<>();m.put("name",n);m.put("createdAt",FieldValue.serverTimestamp());m.put("createdBy",auth.getUid());
                  db.collection("materials").add(m).addOnSuccessListener(x->{toast("Material added");loadSpinnerValues("materials","name",spinner,"No material added");});
              });
          }).setNegativeButton("Cancel",null).show();
    }

    void purchaseHistory(){
        db.collection("materialPurchases").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener(q->{
            StringBuilder out=new StringBuilder();
            if(q.isEmpty()) out.append("No purchase entries");
            for(DocumentSnapshot s:q){
                out.append("Party: ").append(s.getString("party")).append("\n");
                out.append("Material: ").append(s.getString("material")).append("\n");
                out.append("Purchased: ").append(fmt(s.getDouble("kg"))).append(" KG\n\n");
            }
            new AlertDialog.Builder(this).setTitle("Purchase History").setMessage(out.toString()).setPositiveButton("OK",null).show();
        }).addOnFailureListener(e->toast("Purchase history load nahi hua"));
    }

    void loadSpinnerValues(String collection,String fieldName,Spinner spinner,String emptyLabel){
        db.collection(collection).orderBy(fieldName).get().addOnSuccessListener(q->{
            ArrayList<String> values=new ArrayList<>();
            for(DocumentSnapshot s:q){String v=s.getString(fieldName);if(v!=null&&!v.trim().isEmpty())values.add(v);}
            if(values.isEmpty())values.add(emptyLabel);
            ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);
        }).addOnFailureListener(e->{ArrayList<String> values=new ArrayList<>();values.add(emptyLabel);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);spinner.setAdapter(a);});
    }

    String selectedSpinner(Spinner spinner){Object o=spinner.getSelectedItem();return o==null?"":o.toString().trim();}

    TextView label(String text){TextView t=new TextView(this);t.setText(text);t.setTextSize(14);t.setPadding(0,8,0,0);return t;}
    Button smallButton(String text){Button b=new Button(this);b.setText(text);b.setTextSize(11);return b;}

    void labourJobDialog(){
        LinearLayout l=box();

        LinearLayout partyRow=new LinearLayout(this); partyRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner labourPartySpinner=new Spinner(this); Button addLabourParty=smallButton("+ Add Labour Party");
        partyRow.addView(labourPartySpinner,new LinearLayout.LayoutParams(0,-2,1)); partyRow.addView(addLabourParty);
        l.addView(label("Labour Party")); l.addView(partyRow);

        LinearLayout materialRow=new LinearLayout(this); materialRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner materialSpinner=new Spinner(this); Button addMaterial=smallButton("+ Add Material");
        materialRow.addView(materialSpinner,new LinearLayout.LayoutParams(0,-2,1)); materialRow.addView(addMaterial);
        l.addView(label("Material / Powder")); l.addView(materialRow);

        EditText given=field("Powder Given KG",true);
        EditText returned=field("Unused Powder Returned KG",true);
        EditText product=field("Product Made",false);
        EditText output=field("Finished Item Output KG",true);
        l.addView(given); l.addView(returned); l.addView(product); l.addView(output);

        loadSpinnerValues("labourParties","name",labourPartySpinner,"No labour party added");
        loadSpinnerValues("materials","name",materialSpinner,"No material added");
        addLabourParty.setOnClickListener(v->addLabourPartyDialog(labourPartySpinner));
        addMaterial.setOnClickListener(v->addMaterialDialog(materialSpinner));

        new AlertDialog.Builder(this).setTitle("Labour Job")
          .setMessage("Labour party + material + powder given/returned + production enter karein")
          .setView(l).setPositiveButton("Save",(d,w)->{
            String party=selectedSpinner(labourPartySpinner), material=selectedSpinner(materialSpinner);
            String productName=product.getText().toString().trim();
            if(party.isEmpty() || party.startsWith("No ")){toast("Pehle labour party add karein");return;}
            if(material.isEmpty() || material.startsWith("No ")){toast("Pehle material add karein");return;}
            if(productName.isEmpty()){toast("Product name bharein");return;}
            try{
                double g=Double.parseDouble(given.getText().toString().trim());
                double r=returned.getText().toString().trim().isEmpty()?0:Double.parseDouble(returned.getText().toString().trim());
                double o=output.getText().toString().trim().isEmpty()?0:Double.parseDouble(output.getText().toString().trim());
                if(g<=0 || r<0 || o<0){toast("KG values sahi bharein");return;}
                if(r>g){toast("Returned KG given KG se zyada nahi ho sakta");return;}
                Map<String,Object> m=new HashMap<>();
                m.put("party",party); m.put("material",material); m.put("givenKg",g);
                m.put("returnedPowderKg",r); m.put("product",productName); m.put("outputKg",o);
                m.put("createdAt",FieldValue.serverTimestamp()); m.put("createdBy",auth.getUid());
                db.collection("labourJobs").add(m).addOnSuccessListener(x->{toast("Labour job saved: "+party+" → "+material+" → "+fmt(g)+" KG");loadSummary();});
            }catch(Exception e){toast("KG sahi bharein");}
        }).setNegativeButton("Cancel",null).setNeutralButton("Labour Hisab",(d,w)->report()).show();
    }

    void addLabourPartyDialog(Spinner spinner){
        EditText e=field("Labour party name",false);
        new AlertDialog.Builder(this).setTitle("Add Labour Party").setView(e)
          .setPositiveButton("Save",(d,w)->{
              String n=e.getText().toString().trim();
              if(n.isEmpty()){toast("Labour party name bharein");return;}
              db.collection("labourParties").whereEqualTo("name",n).limit(1).get().addOnSuccessListener(q->{
                  if(!q.isEmpty()){toast("Labour party already added");loadSpinnerValues("labourParties","name",spinner,"No labour party added");return;}
                  Map<String,Object> m=new HashMap<>(); m.put("name",n); m.put("createdAt",FieldValue.serverTimestamp()); m.put("createdBy",auth.getUid());
                  db.collection("labourParties").add(m).addOnSuccessListener(x->{toast("Labour party added");loadSpinnerValues("labourParties","name",spinner,"No labour party added");});
              });
          }).setNegativeButton("Cancel",null).show();
    }

    void stockReport(){
        db.collection("materialPurchases").get().addOnSuccessListener(pq->db.collection("labourJobs").get().addOnSuccessListener(lq->{
            HashMap<String,Double> bal=new HashMap<>();
            for(DocumentSnapshot s:pq){String m=s.getString("material");if(m==null)m="Unknown";bal.put(m,bal.getOrDefault(m,0.0)+val(s.getDouble("kg")));}
            for(DocumentSnapshot s:lq){String m=s.getString("material");if(m==null)m="Unknown";double x=bal.getOrDefault(m,0.0)-val(s.getDouble("givenKg"))+val(s.getDouble("returnedPowderKg"));bal.put(m,x);}
            StringBuilder out=new StringBuilder("Powder / Material Balance\n\n");for(String m:bal.keySet())out.append(m).append(" : ").append(fmt(bal.get(m))).append(" KG\n");
            new AlertDialog.Builder(this).setTitle("Current Stock").setMessage(out.toString()).setPositiveButton("OK",null).show();
        }));
    }

    void loadSummary(){
        db.collection("parties").get().addOnSuccessListener(partyQ -> {
            final int partyCount=partyQ.size();
            db.collection("materialPurchases").get().addOnSuccessListener(pq->db.collection("labourJobs").get().addOnSuccessListener(lq->{
            double purchase=0,given=0,returned=0,output=0;for(DocumentSnapshot s:pq)purchase+=val(s.getDouble("kg"));
            for(DocumentSnapshot s:lq){given+=val(s.getDouble("givenKg"));returned+=val(s.getDouble("returnedPowderKg"));output+=val(s.getDouble("outputKg"));}
            double balance=purchase-given+returned;
            dashboardSummary.setText("PARTY & STOCK DASHBOARD\n\nTotal Parties       : "+partyCount+"\nPowder Balance     : "+fmt(balance)+" KG\nLabour Given        : "+fmt(given)+" KG\nPowder Returned     : "+fmt(returned)+" KG\nFinished Production : "+fmt(output)+" KG");
            summary.setText("Powder Purchased: "+fmt(purchase)+" KG\nPowder Given to Labour: "+fmt(given)+" KG\nPowder Returned: "+fmt(returned)+" KG\nPowder Balance: "+fmt(balance)+" KG\nFinished Output: "+fmt(output)+" KG");
        }));
        });
    }

    void labourPartyHisab(){
        db.collection("labourJobs").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener(q->{
            if(q.isEmpty()){ new AlertDialog.Builder(this).setTitle("Labour Party Hisab").setMessage("No labour entries").setPositiveButton("OK",null).show(); return; }
            LinkedHashMap<String,Double> totals=new LinkedHashMap<>();
            LinkedHashMap<String,LinkedHashMap<String,Double>> itemTotals=new LinkedHashMap<>();
            for(DocumentSnapshot s:q){
                String party=s.getString("party"); if(party==null||party.trim().isEmpty()) party="Unknown";
                String product=s.getString("product"); if(product==null||product.trim().isEmpty()) product="Unknown Item";
                double out=val(s.getDouble("outputKg"));
                totals.put(party,totals.getOrDefault(party,0.0)+out);
                if(!itemTotals.containsKey(party)) itemTotals.put(party,new LinkedHashMap<>());
                LinkedHashMap<String,Double> items=itemTotals.get(party);
                items.put(product,items.getOrDefault(product,0.0)+out);
            }
            LinearLayout box=box();
            EditText search=field("Search labour party (e.g. B)",false); box.addView(search);
            TextView result=new TextView(this); result.setTextSize(16); result.setPadding(0,16,0,8); box.addView(result);
            Runnable render=()->{
                String term=search.getText().toString().trim().toLowerCase(Locale.US);
                StringBuilder out=new StringBuilder();
                for(String party:totals.keySet()){
                    if(!term.isEmpty()&&!party.toLowerCase(Locale.US).contains(term)) continue;
                    out.append("LABOUR PARTY: ").append(party).append("\n");
                    out.append("Total Item Given Back: ").append(fmt(totals.get(party))).append(" KG\n");
                    out.append("Item-wise:\n");
                    for(Map.Entry<String,Double> e:itemTotals.get(party).entrySet()) out.append("  ").append(e.getKey()).append(" → ").append(fmt(e.getValue())).append(" KG\n");
                    out.append("\n");
                }
                if(out.length()==0) out.append("Labour party nahi mili");
                result.setText(out.toString());
            };
            render.run();
            search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){render.run();} public void afterTextChanged(android.text.Editable e){}});
            new AlertDialog.Builder(this).setTitle("Labour Party Hisab").setView(box).setPositiveButton("Close",null).show();
        }).addOnFailureListener(e->toast("Labour hisab load nahi hua"));
    }

    void report(){
        db.collection("labourJobs").orderBy("createdAt",Query.Direction.DESCENDING).get().addOnSuccessListener(q->{StringBuilder x=new StringBuilder();for(DocumentSnapshot s:q)x.append(s.getString("party")).append(" • ").append(s.getString("material")).append("\n").append(s.getString("product")).append(" → ").append(fmt(s.getDouble("outputKg"))).append(" KG | Given ").append(fmt(s.getDouble("givenKg"))).append(" KG\n\n");new AlertDialog.Builder(this).setTitle("Labour Hisab").setMessage(x.length()==0?"No entries":x.toString()).setPositiveButton("OK",null).show();});
    }

    void backupCsv(){
        db.collection("labourJobs").get().addOnSuccessListener(q->{StringBuilder c=new StringBuilder("Party,Material,PowderGivenKG,PowderReturnedKG,Product,OutputKG\n");for(DocumentSnapshot s:q)c.append(csv(s.getString("party"))).append(',').append(csv(s.getString("material"))).append(',').append(fmt(s.getDouble("givenKg"))).append(',').append(fmt(s.getDouble("returnedPowderKg"))).append(',').append(csv(s.getString("product"))).append(',').append(fmt(s.getDouble("outputKg"))).append('\n');Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/csv");i.putExtra(Intent.EXTRA_TEXT,c.toString());startActivity(Intent.createChooser(i,"Backup CSV share karein"));});
    }

    LinearLayout box(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(30,10,30,10);return l;}
    double val(Double d){return d==null?0:d;} String fmt(Double d){return String.format(Locale.US,"%.3f",val(d));}
    String csv(String s){return "\""+(s==null?"":s.replace("\"","\"\""))+"\"";} void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
